# Xtreem Service Tour and Travel — Landing Page

A responsive, single-page travel agency website built with HTML, CSS, and vanilla JavaScript.

## Run locally
Open `index.html` in a browser. No build step or package installation is required.

## Included
- Responsive navigation with mobile menu
- Scenic hero and call-to-action buttons
- Destination/month selector and traveller counter
- Interactive featured package filtering
- Six tour cards with prices and durations
- About, features, stats, testimonials, CTA banner, and contact footer
- Click-to-call phone links and email link

## Before production
- Confirm the stats and testimonial wording are accurate and approved.
- Connect the search/quote form to a booking backend, CRM, or email service. It currently filters the featured cards and displays a status message; it does not create a reservation.
- Replace stock image URLs with licensed/approved images if needed.
- Add real social profile URLs.
- Add analytics, privacy policy, and cookie handling if required.
- Verify all package prices, availability, address, and contact details before publishing.

## Deploy
Upload `index.html` to any static host (Netlify, Vercel, GitHub Pages, or your web host). For Vercel/Netlify, the project root is this folder and no build command is needed.
